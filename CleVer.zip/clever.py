# -*- coding: utf-8 -*-
from bot import *

if __name__ == "__main__":
	try:
		clever_()
	except KeyboardInterrupt:
		print 'CTRL+C'
		os._exit()