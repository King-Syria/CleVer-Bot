مرحبا ! ...

بوت كليفير يعمل مع نظام ايجابرد

المتطلبات :

سيرفر ليونكس x86_64 ابونتو فوق ١٤

يجب عليك تنصيب البرامج التالية :

apt-get install python 2.7

pip2 install zope.interface==5.4.0

pip2 install termcolor==1.1.0

pip2 install Twisted==13.0.0

pip2 install requests

ثم تعديل ملف الاعدادات :

a_settings.py / other.py

بعدها تشغيل ملف البوت :

python2 ./clever.py

للمساعدة اضفني :

king-syria@syriatalk.org (الحساب الاساسي)
king-syria@syriatalk.info (الحساب الاساسي)

هذا كل شيئ شكرا لكم 

© By KinG-SyRia
=====================
welcome ! ... 

Bot clever works with the Ejabberd system

Requirements:

Linux x86_64 server Ubuntu up 14

You must install the following programs:

apt-get install python 2

pip2 install zope.interface==5.4.0

pip2 install termcolor==1.1.0

pip2 install Twisted==13.0.0

pip2 install requests

Then modify the settings file:

a_settings.py and other.py

Then run the bot file:

python2 ./clever.py

For help, add:

king-syria@syriatalk.org (main account)
king-syria@syriatalk.info (main account)

That's it, thank you

© By KinG-SyRia